import pytesseract as tess

# Setting Environmental Variable
tess.pytesseract.tesseract_cmd = r'C:\Users\afaqm\AppData\Local\Tesseract-OCR\tesseract.exe'
from PIL import Image

# Given Sample
img = Image.open("./Data Samples/DFS-sample-cert2.jpg")
text = tess.image_to_string(img)
print(text)

# One More Test
img = Image.open("./Data Samples/winstonchurchill1.jpg")
text = tess.image_to_string(img)
print(text)

# Converting Handwritten Image
img = Image.open("./Data Samples/53db32076c4bb6b8aef3f2579d6dac6b.jpg")
text = tess.image_to_string(img)
print(text)