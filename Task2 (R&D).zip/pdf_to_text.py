from PyPDF2 import PdfReader
reader = PdfReader("./Data Samples/Propsal (Urdu Grammarly).pdf")
page = reader.pages[1]
print(page.extract_text())