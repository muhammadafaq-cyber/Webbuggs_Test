from .models import Supplier, Shop
from.serializers import Supplierserializer, Shopserializer
from rest_framework import viewsets
from rest_framework.filters import SearchFilter

# Supplier View Set
class SuppliersViewSet(viewsets.ModelViewSet):
    serializer_class = Supplierserializer
    def get_queryset(self):
        supplier = Supplier.objects.all().order_by('-shop_count')[:3]
        return supplier

# Shop View Set
class ShopsViewSet(viewsets.ModelViewSet):
    serializer_class = Shopserializer
    queryset = Shop.objects.all()
    filter_backends = [SearchFilter]
    search_fields = ['shopname']

    