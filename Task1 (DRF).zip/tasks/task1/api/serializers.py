from rest_framework import serializers
from .models import Supplier, Shop

class Supplierserializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        fields = ['name', 'adress','shop']
        depth = 1
    
class Shopserializer(serializers.ModelSerializer):
    class Meta:
        model = Shop
        fields = ['shopname','suppliers_data']    