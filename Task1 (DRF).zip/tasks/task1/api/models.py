from django.db import models

# Create your models here.
class Shop(models.Model):
    shopname = models.CharField(max_length = 100)
    def __str__(self):
        return self.shopname
    
    def suppliers_data(self):
        return ' , '.join([str(s) for s in self.shop_suppliers.all()])

class Supplier(models.Model):
    #many to many relationship
    shop = models.ManyToManyField(Shop, related_name = 'shop_suppliers')
    name = models.CharField(max_length=50)
    adress = models.CharField(max_length= 100)
    shop_count = models.IntegerField()
    def __str__(self):
        return self.name
    