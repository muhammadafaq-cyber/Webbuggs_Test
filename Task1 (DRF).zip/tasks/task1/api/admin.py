from django.contrib import admin
from .models import Supplier, Shop

# Register your models here.
admin.site.register(Shop)
admin.site.register(Supplier)

class ShopAdmin(admin.ModelAdmin):
    list_display =  ['id', 'shopname']

class SupplierAdmin(admin.ModelAdmin):
    list_display =  ['id', 'name', 'adress','shop_count','shop']