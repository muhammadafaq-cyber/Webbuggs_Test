from django.urls import path, include
from django.contrib import admin
from api.views import SuppliersViewSet, ShopsViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register("suppliers", SuppliersViewSet, basename="supplier")
router.register("shops", ShopsViewSet, basename="shop")

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(router.urls))
]